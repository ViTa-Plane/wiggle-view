import os
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame, QSizePolicy
from PySide6.QtCore import Qt, Signal, QRect, QPoint
from PySide6.QtGui import QColor, QPixmap, QPainter, QFont, QPen, QWheelEvent, QMouseEvent, QKeyEvent, QImageReader


class ImageViewerWindow(QWidget):
    """
    Minimalistic borderless image viewer window supporting fit-to-window scaling,
    cursor-centered wheel zooming, click-and-drag panning, double-click fullscreen toggle,
    Esc to close, and arrow key folder navigation.
    """

    def __init__(self, image_path, items_list=None, parent=None):
        if isinstance(items_list, QWidget):
            parent = items_list
            items_list = getattr(parent, "loaded_items", [])

        super().__init__(parent)
        self.image_path = image_path
        self.items = items_list or []
        self.main_parent = parent

        self.current_index = 0
        for i, item in enumerate(self.items):
            if item.get("file_path") == image_path:
                self.current_index = i
                break

        self.setWindowTitle("Image Viewer")
        self.resize(900, 650)
        self.setMinimumSize(400, 300)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.original_pixmap = QPixmap(image_path)
        self._setup_viewer_ui()
        self.setFocus()

    def closeEvent(self, event):
        if self.main_parent:
            self.main_parent.show()
        event.accept()

    def keyPressEvent(self, event: QKeyEvent):
        """Handles keyboard navigation: Esc to close, Arrow keys to flip images."""
        key = event.key()
        if key == Qt.Key.Key_Escape:
            self.close()
            event.accept()
        elif key in (Qt.Key.Key_Right, Qt.Key.Key_Down):
            self.navigate(1)
            event.accept()
        elif key in (Qt.Key.Key_Left, Qt.Key.Key_Up):
            self.navigate(-1)
            event.accept()
        else:
            super().keyPressEvent(event)

    def navigate(self, direction):
        if not self.items:
            return

        self.current_index = (self.current_index + direction) % len(self.items)
        next_item = self.items[self.current_index]
        self.image_path = next_item["file_path"]

        # Load pixmap safely
        self.original_pixmap = QPixmap(self.image_path)
        self.canvas.set_pixmap(self.original_pixmap)

        file_title = os.path.basename(self.image_path)

        # Get dimensions safely using QImageReader for the title
        reader = QImageReader(self.image_path)
        size = reader.size()
        dim_info = f" ({size.width()}x{size.height()})" if size.isValid() else ""

        self.title_label.setText(f"🔍 Viewing: {file_title}{dim_info} (Double-click to toggle Fullscreen)")

        if self.main_parent and hasattr(self.main_parent, 'workspace_grid'):
            self.main_parent.workspace_grid.selected_file_path = self.image_path
            self.main_parent.workspace_grid.update()
            self.main_parent.set_status(f"Viewing: {file_title}")

    def _setup_viewer_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(8, 8, 8, 8)

        self.container = QFrame(self)
        self.container.setStyleSheet("""
            QFrame {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 10px;
            }
        """)

        container_layout = QVBoxLayout(self.container)
        container_layout.setContentsMargins(10, 10, 10, 10)
        container_layout.setSpacing(8)

        self.title_container = QWidget(self.container)
        title_layout = QHBoxLayout(self.title_container)
        title_layout.setContentsMargins(4, 0, 4, 0)

        file_title = os.path.basename(self.image_path)
        self.title_label = QLabel(f"🔍 Viewing: {file_title} (Double-click to toggle Fullscreen)")
        self.title_label.setStyleSheet("color: #cbd5e1; font-size: 12px; font-weight: bold; background: transparent;")
        title_layout.addWidget(self.title_label)

        title_layout.addStretch()

        btn_close = QPushButton("✕")
        btn_close.setFixedSize(26, 26)
        btn_close.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_close.setStyleSheet("""
            QPushButton {
                background-color: #131b2e;
                color: #94a3b8;
                border: 1px solid #1e293b;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #ef4444;
                color: #ffffff;
                border-color: #ef4444;
            }
        """)
        btn_close.clicked.connect(self.close)
        title_layout.addWidget(btn_close)

        container_layout.addWidget(self.title_container)

        self.canvas = ImageViewCanvas(self.original_pixmap, self)
        self.canvas.key_pressed.connect(self.keyPressEvent)
        self.canvas.double_clicked.connect(self.toggle_fullscreen)
        container_layout.addWidget(self.canvas, stretch=1)

        main_layout.addWidget(self.container)

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            self.title_container.setVisible(True)
            self.container.setStyleSheet("""
                QFrame {
                    background-color: #0b0f19;
                    border: 1px solid #1e293b;
                    border-radius: 10px;
                }
            """)
        else:
            self.showFullScreen()
            self.title_container.setVisible(False)
            self.container.setStyleSheet("""
                QFrame {
                    background-color: #0b0f19;
                    border: none;
                    border-radius: 0px;
                }
            """)
        self.canvas.reset_fit()

    def mousePressEvent(self, event):
        if not self.isFullScreen() and event.position().y() < 40:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if not self.isFullScreen() and hasattr(self, '_drag_pos') and event.position().y() < 40:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()


class ImageViewCanvas(QWidget):
    """Custom paint canvas handling fit-to-window, cursor-centered zoom, drag pan, and double-click fullscreen."""
    double_clicked = Signal()
    key_pressed = Signal(QKeyEvent)

    def __init__(self, pixmap, parent=None):
        super().__init__(parent)
        self.pixmap = pixmap
        self.zoom = 1.0
        self.offset = QPoint(0, 0)
        self.dragging = False
        self.drag_start = QPoint(0, 0)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.setMouseTracking(True)
        self._initial_fit_calculated = False

    def set_pixmap(self, pixmap):
        self.pixmap = pixmap
        self.reset_fit()

    def reset_fit(self):
        self.zoom = 1.0
        self.offset = QPoint(0, 0)
        self._initial_fit_calculated = False
        self.update()

    def wheelEvent(self, event: QWheelEvent):
        angle = event.angleDelta().y()
        zoom_multiplier = 1.15 if angle > 0 else 0.85

        old_zoom = self.zoom
        new_zoom = max(0.1, min(20.0, old_zoom * zoom_multiplier))
        if new_zoom == old_zoom:
            return

        self.zoom = new_zoom
        mouse_pos = event.position().toPoint()
        scale_ratio = self.zoom / old_zoom
        self.offset = mouse_pos - (mouse_pos - self.offset) * scale_ratio
        self.update()

    def keyPressEvent(self, event: QKeyEvent):
        self.key_pressed.emit(event)

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self.dragging = True
            self.drag_start = event.position().toPoint() - self.offset
            self.setCursor(Qt.CursorShape.ClosedHandCursor)

    def mouseMoveEvent(self, event: QMouseEvent):
        if self.dragging:
            self.offset = event.position().toPoint() - self.drag_start
            self.update()

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self.dragging = False
            self.setCursor(Qt.CursorShape.OpenHandCursor)

    def mouseDoubleClickEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self.double_clicked.emit()
        super().mouseDoubleClickEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        painter.fillRect(self.rect(), QColor("#05070a"))

        if self.pixmap.isNull():
            return

        widget_size = self.size()
        pixmap_size = self.pixmap.size()

        fit_scale = min(
            widget_size.width() / pixmap_size.width(),
            widget_size.height() / pixmap_size.height()
        )

        current_scale = fit_scale * self.zoom
        scaled_w = int(pixmap_size.width() * current_scale)
        scaled_h = int(pixmap_size.height() * current_scale)

        if not self._initial_fit_calculated and self.offset == QPoint(0, 0):
            x = (widget_size.width() - scaled_w) // 2
            y = (widget_size.height() - scaled_h) // 2
            self.offset = QPoint(x, y)
            self._initial_fit_calculated = True

        target_rect = QRect(int(self.offset.x()), int(self.offset.y()), scaled_w, scaled_h)
        painter.drawPixmap(target_rect, self.pixmap)