import sys
from PySide6.QtWidgets import QApplication
from app.ui import MainWindow

if __name__ == "__main__":
    app = QApplication(sys.argv)

    # App is fully self-contained with hardcoded Python styles; no external QSS needed!
    window = MainWindow()
    window.show()

    sys.exit(app.exec())