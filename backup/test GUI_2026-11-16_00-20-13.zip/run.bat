@echo off
cd /d "%~dp0"
@echo start QuickView...
.venv\Scripts\python.exe main.py %*





