import os
import json
import tempfile
import hashlib
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QToolBar, QFrame,
    QGraphicsDropShadowEffect, QMenuBar, QTabWidget, QTextEdit,
    QFileDialog, QListWidget, QListWidgetItem
)
from PySide6.QtCore import Qt, QSize, QRunnable, QThreadPool, Signal, QObject, QTimer
from PySide6.QtGui import QAction, QColor, QPixmap, QIcon, QPainter
from functions import WindowDragHandler, TitleBar
from dialogs import ChildTestDialog, AboutDialog, SettingsDialog, ResizeHandleWidget

SETTINGS_FILE = "settings.json"


class FolderScannerSignals(QObject):
    """Signals for thread-safe folder scanning and batched list item population."""
    batch_scanned = Signal(list)  # Emits batches of (file_path, display_name) tuples
    scan_complete = Signal(int)  # Emits total file count


class FolderScannerTask(QRunnable):
    """Background worker task to scan huge directories without freezing the GUI."""

    def __init__(self, folder_path, signals):
        super().__init__()
        self.folder_path = folder_path
        self.signals = signals

    def run(self):
        valid_extensions = ('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.webp')
        try:
            if not os.path.isdir(self.folder_path):
                return

            batch = []
            total_count = 0

            for f in os.listdir(self.folder_path):
                if f.lower().endswith(valid_extensions):
                    file_path = os.path.join(self.folder_path, f)
                    display_name = (f[:16] + '..') if len(f) > 18 else f
                    batch.append((file_path, display_name))
                    total_count += 1

                    # Stream items in chunks of 50 to keep memory low and UI responsive
                    if len(batch) >= 50:
                        self.signals.batch_scanned.emit(batch)
                        batch = []

            if batch:
                self.signals.batch_scanned.emit(batch)

            self.signals.scan_complete.emit(total_count)
        except Exception:
            pass


class ThumbnailSignalEmitter(QObject):
    """Signals for thread-safe asynchronous thumbnail loading communication."""
    thumbnail_ready = Signal(str, str)  # file_path, thumb_cache_path


class ThumbnailLoaderTask(QRunnable):
    """Background worker task to load, downscale, and uniform-canvas cache image thumbnails."""

    def __init__(self, file_path, cache_dir, target_size, signals):
        super().__init__()
        self.file_path = file_path
        self.cache_dir = cache_dir
        self.target_size = target_size
        self.signals = signals

    def run(self):
        try:
            path_hash = hashlib.md5(self.file_path.encode('utf-8')).hexdigest()
            thumb_filename = f"thumb_{path_hash}_{self.target_size}.jpg"
            thumb_path = os.path.join(self.cache_dir, thumb_filename)

            if not os.path.exists(thumb_path):
                pixmap = QPixmap(self.file_path)
                if not pixmap.isNull():
                    scaled = pixmap.scaled(
                        self.target_size, self.target_size,
                        Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation
                    )

                    canvas = QPixmap(self.target_size, self.target_size)
                    canvas.fill(Qt.GlobalColor.transparent)

                    painter = QPainter(canvas)
                    x = (self.target_size - scaled.width()) // 2
                    y = (self.target_size - scaled.height()) // 2
                    painter.drawPixmap(x, y, scaled)
                    painter.end()

                    canvas.save(thumb_path, "JPG", 88)

            if os.path.exists(thumb_path):
                self.signals.thumbnail_ready.emit(self.file_path, thumb_path)
        except Exception:
            pass


class MainWindow(QMainWindow, WindowDragHandler):
    """Main application dashboard with threaded folder scanner and lightning-fast streaming cards."""

    def __init__(self):
        super().__init__(parent=None)
        WindowDragHandler.__init__(self)
        self.resize(1100, 720)
        self.setMinimumSize(750, 500)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        # --- Card Size Configuration ---
        self.CARD_IMAGE_SIZE = 170
        self.GRID_CELL_WIDTH = 200
        self.GRID_CELL_HEIGHT = 220

        # --- Async, Caching & Threading Setup ---
        self.thread_pool = QThreadPool.globalInstance()

        self.thumbnail_signals = ThumbnailSignalEmitter()
        self.thumbnail_signals.thumbnail_ready.connect(self.on_thumbnail_ready)

        self.scanner_signals = FolderScannerSignals()
        self.scanner_signals.batch_scanned.connect(self.on_batch_scanned)
        self.scanner_signals.scan_complete.connect(self.on_scan_complete)

        self.thumb_cache_dir = os.path.join(tempfile.gettempdir(), "pyqt_slate_thumbnail_cache")
        os.makedirs(self.thumb_cache_dir, exist_ok=True)

        self.pending_thumbnail_files = []
        self.batch_timer = QTimer(self)
        self.batch_timer.setInterval(25)
        self.batch_timer.timeout.connect(self.process_next_thumbnail_batch)

        self._setup_ui()

        # --- Load Last Opened Folder on Startup ---
        self.load_last_folder()

    def _setup_ui(self):
        central_widget = QWidget(self)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(12, 12, 12, 12)

        self.container = QFrame(central_widget)
        self.container.setStyleSheet("""
            QFrame {
                background-color: #0d1321;
                border: 1px solid #1e293b;
                border-radius: 12px;
            }
        """)

        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 160))
        shadow.setOffset(0, 4)
        self.container.setGraphicsEffect(shadow)

        container_layout = QVBoxLayout(self.container)
        container_layout.setContentsMargins(16, 16, 16, 16)
        container_layout.setSpacing(14)

        container_layout.addWidget(TitleBar("🚀 Main Application Dashboard", self, show_min_max=True))

        # --- Global Application Stylesheet (Scrollbars & Theme) ---
        self.setStyleSheet("""
            QScrollBar:vertical {
                background: #0b0f19;
                width: 12px;
                margin: 0px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background: #1e293b;
                min-height: 30px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical:hover {
                background: #334155;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
                background: none;
            }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: none;
            }

            QScrollBar:horizontal {
                background: #0b0f19;
                height: 12px;
                margin: 0px;
                border-radius: 6px;
            }
            QScrollBar::handle:horizontal {
                background: #1e293b;
                min-width: 30px;
                border-radius: 6px;
            }
            QScrollBar::handle:horizontal:hover {
                background: #334155;
            }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                width: 0px;
                background: none;
            }
            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
                background: none;
            }
        """)

        # --- Menu Bar ---
        self.menu_bar = QMenuBar(self)
        self.menu_bar.setStyleSheet("""
            QMenuBar {
                background-color: #131b2e;
                color: #cbd5e1;
                font-family: sans-serif;
                font-size: 13px;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 4px;
            }
            QMenuBar::item {
                background: transparent;
                padding: 6px 12px;
                border-radius: 4px;
            }
            QMenuBar::item:selected {
                background-color: #1e293b;
                color: #ffffff;
            }
            QMenu {
                background-color: #0d1321;
                color: #cbd5e1;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 4px;
            }
            QMenu::item {
                padding: 6px 24px;
                border-radius: 4px;
            }
            QMenu::item:selected {
                background-color: #1e293b;
                color: #ffffff;
            }
        """)

        file_menu = self.menu_bar.addMenu("File")
        new_action = QAction("New", self)
        new_action.triggered.connect(lambda: self.set_status("Created new file"))
        open_action = QAction("Open...", self)
        open_action.triggered.connect(self.open_folder_dialog)

        # New command to reopen the last folder directly
        open_last_action = QAction("Open Last Folder", self)
        open_last_action.triggered.connect(self.load_last_folder)

        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(new_action)
        file_menu.addAction(open_action)
        file_menu.addSeparator()
        file_menu.addAction(exit_action)

        edit_menu = self.menu_bar.addMenu("Edit")
        undo_action = QAction("Undo", self)
        undo_action.triggered.connect(lambda: self.set_status("Action undone"))
        redo_action = QAction("Redo", self)
        redo_action.triggered.connect(lambda: self.set_status("Action redone"))
        edit_menu.addAction(undo_action)
        edit_menu.addAction(redo_action)

        about_menu = self.menu_bar.addMenu("About")
        about_action = QAction("About App", self)
        about_action.triggered.connect(self.show_about_dialog)
        about_menu.addAction(about_action)

        container_layout.addWidget(self.menu_bar)

        # --- Main Body 3-Column Split Layout ---
        body_split_layout = QHBoxLayout()
        body_split_layout.setSpacing(12)

        # 1. Left-Side Toolbar Panel
        self.sidebar_frame = QFrame(self)
        self.sidebar_frame.setFixedWidth(150)
        self.sidebar_frame.setStyleSheet("""
            QFrame {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 8px;
            }
        """)
        sidebar_layout = QVBoxLayout(self.sidebar_frame)
        sidebar_layout.setContentsMargins(8, 12, 8, 12)
        sidebar_layout.setSpacing(8)

        sidebar_title = QLabel("TOOLS")
        sidebar_title.setStyleSheet(
            "color: #64748b; font-family: sans-serif; font-size: 11px; font-weight: bold; background: transparent; padding-left: 4px;")
        sidebar_layout.addWidget(sidebar_title)

        tool_btn_style = """
            QPushButton {
                background-color: #131b2e;
                color: #cbd5e1;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 8px 12px;
                font-weight: 600;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #1e293b;
                color: #f8fafc;
                border-color: #334155;
            }
            QPushButton:pressed {
                background-color: #0d1321;
            }
        """

        btn_dashboard = QPushButton("📊 Dashboard")
        btn_dashboard.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_dashboard.setStyleSheet(tool_btn_style)
        btn_dashboard.clicked.connect(lambda: self.set_status("Switched to Dashboard"))
        sidebar_layout.addWidget(btn_dashboard)

        btn_analytics = QPushButton("📈 Analytics")
        btn_analytics.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_analytics.setStyleSheet(tool_btn_style)
        btn_analytics.clicked.connect(lambda: self.set_status("Switched to Analytics"))
        sidebar_layout.addWidget(btn_analytics)

        btn_settings = QPushButton("⚙️ Settings")
        btn_settings.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_settings.setStyleSheet(tool_btn_style)
        btn_settings.clicked.connect(self.open_settings_dialog)
        sidebar_layout.addWidget(btn_settings)

        sidebar_layout.addStretch()

        btn_child = QPushButton("📂 Child Win")
        btn_child.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_child.setStyleSheet("""
            QPushButton {
                background-color: #3b82f6;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 12px;
                font-weight: bold;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #2563eb;
            }
        """)
        btn_child.clicked.connect(self.open_child_window)
        sidebar_layout.addWidget(btn_child)

        body_split_layout.addWidget(self.sidebar_frame)

        # 2. Center Workspace Area
        center_container = QWidget(self)
        center_container.setStyleSheet("background: transparent;")
        center_layout = QVBoxLayout(center_container)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(10)

        instruction_label = QLabel("Select a folder via 'File -> Open...' to view image thumbnail cards.")
        instruction_label.setStyleSheet(
            "color: #f8fafc; font-family: sans-serif; font-size: 13px; background: transparent;")
        center_layout.addWidget(instruction_label)

        # --- Thumbnail Grid List Widget ---
        self.thumbnail_list = QListWidget()
        self.thumbnail_list.setViewMode(QListWidget.ViewMode.IconMode)
        self.thumbnail_list.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.thumbnail_list.setMovement(QListWidget.Movement.Static)

        self.thumbnail_list.setIconSize(QSize(self.CARD_IMAGE_SIZE, self.CARD_IMAGE_SIZE))
        self.thumbnail_list.setGridSize(QSize(self.GRID_CELL_WIDTH, self.GRID_CELL_HEIGHT))
        self.thumbnail_list.setSpacing(6)
        self.thumbnail_list.setUniformItemSizes(True)

        self.thumbnail_list.setStyleSheet("""
            QListWidget {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 8px;
                padding: 8px;
            }
            QListWidget::item {
                background-color: #131b2e;
                border: 1px solid #1e293b;
                border-radius: 8px;
                padding: 6px;
                color: #cbd5e1;
                font-size: 11px;
                font-weight: 500;
            }
            QListWidget::item:selected {
                background-color: #1e293b;
                border-color: #3b82f6;
                color: #ffffff;
            }
        """)
        center_layout.addWidget(self.thumbnail_list, stretch=1)

        body_split_layout.addWidget(center_container, stretch=1)

        # 3. Right-Side Panel with Tabs
        self.right_tab_widget = QTabWidget(self)
        self.right_tab_widget.setFixedWidth(240)
        self.right_tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #1e293b;
                background-color: #0b0f19;
                border-radius: 8px;
            }
            QTabBar::tab {
                background-color: #131b2e;
                color: #94a3b8;
                border: 1px solid #1e293b;
                padding: 6px 12px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-right: 2px;
                font-size: 12px;
                font-weight: 600;
            }
            QTabBar::tab:selected {
                background-color: #1e293b;
                color: #f8fafc;
                border-bottom-color: #1e293b;
            }
            QTabBar::tab:hover {
                background-color: #1a233a;
                color: #f1f5f9;
            }
        """)

        # Tab 1: Inspector Panel
        inspector_tab = QWidget()
        inspector_layout = QVBoxLayout(inspector_tab)
        inspector_layout.setContentsMargins(10, 10, 10, 10)
        self.inspector_label = QLabel(
            f"Inspector Properties:\n\n• Folder: None Selected\n• Images Loaded: 0\n• Card Image Size: {self.CARD_IMAGE_SIZE}px")
        self.inspector_label.setWordWrap(True)
        self.inspector_label.setStyleSheet("color: #cbd5e1; font-size: 12px; background: transparent;")
        inspector_layout.addWidget(self.inspector_label)
        inspector_layout.addStretch()
        self.right_tab_widget.addTab(inspector_tab, "Inspector")

        # Tab 2: Activity Log Panel
        log_tab = QWidget()
        log_layout = QVBoxLayout(log_tab)
        log_layout.setContentsMargins(10, 10, 10, 10)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setPlainText("[System] App initialized successfully.")
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #05070a;
                color: #94a3b8;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 6px;
                font-size: 11px;
            }
        """)
        log_layout.addWidget(self.log_text)
        self.right_tab_widget.addTab(log_tab, "Activity")

        body_split_layout.addWidget(self.right_tab_widget)
        container_layout.addLayout(body_split_layout)

        # --- Footer Layout ---
        footer_layout = QHBoxLayout()
        footer_layout.setContentsMargins(0, 0, 0, 0)

        self.status_label = QLabel("Status: Ready")
        self.status_label.setStyleSheet(
            "color: #94a3b8; font-family: sans-serif; font-size: 12px; background: transparent;")
        footer_layout.addWidget(self.status_label)

        footer_layout.addStretch()

        self.resize_handle = ResizeHandleWidget(self)
        footer_layout.addWidget(self.resize_handle, 0, Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignRight)

        container_layout.addLayout(footer_layout)

        main_layout.addWidget(self.container)
        self.setCentralWidget(central_widget)

    def load_last_folder(self):
        """Reads settings.json and restores the previous browsing session if valid."""
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r") as f:
                    data = json.load(f)
                    folder = data.get("last_folder", "")
                    if folder and os.path.isdir(folder):
                        self.load_images_from_folder(folder)
            except Exception as e:
                print(f"Error loading settings: {e}")

    def save_last_folder(self, folder_path):
        """Persists the current folder path to settings.json."""
        try:
            data = {"last_folder": folder_path}
            with open(SETTINGS_FILE, "w") as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"Error saving settings: {e}")

    def set_status(self, message):
        self.status_label.setText(f"Status: {message}")
        if hasattr(self, 'log_text'):
            current_text = self.log_text.toPlainText()
            self.log_text.setPlainText(f"{current_text}\n• {message}")
            self.log_text.verticalScrollBar().setValue(self.log_text.verticalScrollBar().maximum())

    def open_folder_dialog(self):
        folder_path = QFileDialog.getExistingDirectory(self, "Select Image Folder")
        if folder_path:
            self.load_images_from_folder(folder_path)

    def load_images_from_folder(self, folder_path):
        self.batch_timer.stop()
        self.thumbnail_list.clear()
        self.pending_thumbnail_files.clear()
        self.set_status(f"Scanning folder (threaded): {os.path.basename(folder_path)}")

        self.save_last_folder(folder_path)
        self.inspector_label.setText(
            f"Inspector Properties:\n\n• Folder: {os.path.basename(folder_path)}\n• Scanning...")

        # Offload file scanning to background worker thread
        scanner_task = FolderScannerTask(folder_path, self.scanner_signals)
        self.thread_pool.start(scanner_task)

    def on_batch_scanned(self, batch):
        """Receives scanned files in streaming chunks from background thread and populates UI smoothly."""
        for file_path, display_name in batch:
            item = QListWidgetItem(display_name)
            item.setData(Qt.ItemDataRole.UserRole, file_path)
            self.thumbnail_list.addItem(item)
            self.pending_thumbnail_files.append(file_path)

        # Force continuous layout updates so the user can scroll and view items immediately as they stream in
        self.thumbnail_list.doItemsLayout()
        self.thumbnail_list.viewport().update()

        # Kick off thumbnail generation timer if not already running
        if not self.batch_timer.isActive() and self.pending_thumbnail_files:
            self.batch_timer.start()

    def on_scan_complete(self, total_count):
        self.set_status(f"Scan complete. Found {total_count} images. Loading previews...")
        self.inspector_label.setText(
            f"Inspector Properties:\n\n• Folder Selected\n• Total Images: {total_count}")

    def process_next_thumbnail_batch(self):
        """Throttled background loader: triggers thumbnail loading tasks in batches."""
        if not self.pending_thumbnail_files:
            self.batch_timer.stop()
            self.set_status("Gallery loading complete.")
            return

        # Grab a batch of 15 files to generate thumbnails for
        batch = self.pending_thumbnail_files[:15]
        self.pending_thumbnail_files = self.pending_thumbnail_files[15:]

        for file_path in batch:
            task = ThumbnailLoaderTask(file_path, self.thumb_cache_dir, self.CARD_IMAGE_SIZE, self.thumbnail_signals)
            self.thread_pool.start(task)

    def on_thumbnail_ready(self, file_path, thumb_path):
        for i in range(self.thumbnail_list.count()):
            item = self.thumbnail_list.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == file_path:
                pixmap = QPixmap(thumb_path)
                item.setIcon(QIcon(pixmap))
                break

        self.thumbnail_list.scheduleDelayedItemsLayout()
        self.thumbnail_list.viewport().update()

    def open_child_window(self):
        self.set_status("Opening Child Window...")
        dialog = ChildTestDialog(self, custom_title="✨ Child Test Dialog Window")
        dialog.exec()
        self.set_status("Ready")

    def show_about_dialog(self):
        self.set_status("Viewing About Dialog...")
        dialog = AboutDialog(self)
        dialog.exec()
        self.set_status("Ready")

    def open_settings_dialog(self):
        self.set_status("Opening Settings Window...")
        dialog = SettingsDialog(self)
        dialog.exec()
        self.set_status("Ready")

    def mousePressEvent(self, event):
        self.handle_mouse_press(self, event)

    def mouseMoveEvent(self, event):
        self.handle_mouse_move(self, event)