import os
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame, QSizePolicy
from PySide6.QtCore import Qt, Signal, QRect, QPoint, QSize, QRunnable, QThreadPool, QObject
from PySide6.QtGui import QColor, QPixmap, QPainter, QFont, QPen, QWheelEvent, QMouseEvent, QKeyEvent, QImageReader


class ImageLoaderSignals(QObject):
    image_loaded = Signal(str, QPixmap, QSize)  # file_path, pixmap, full_size


class ImageLoaderTask(QRunnable):
    """Background worker task to load and decode huge images off the main GUI thread."""

    def __init__(self, file_path, signals):
        super().__init__()
        self.file_path = file_path
        self.signals = signals

    def run(self):
        reader = QImageReader(self.file_path)
        reader.setAutoTransform(True)
        orig_size = reader.size()

        if not orig_size.isValid():
            pixmap = QPixmap(self.file_path)
            self.signals.image_loaded.emit(self.file_path, pixmap, QSize(0, 0))
            return

        total_pixels = orig_size.width() * orig_size.height()

        # Load a lightweight proxy for images >2MP to keep memory low and rendering instant
        if total_pixels > 2_000_000:
            max_dim = 2560  # 2.5K limit for smooth panning/zooming
            scaled_size = QSize(orig_size)
            scaled_size.scale(max_dim, max_dim, Qt.AspectRatioMode.KeepAspectRatio)
            reader.setScaledSize(scaled_size)
            image = reader.read()
            pixmap = QPixmap.fromImage(image)
        else:
            pixmap = QPixmap(self.file_path)

        self.signals.image_loaded.emit(self.file_path, pixmap, orig_size)


class ImageViewerWindow(QWidget):
    """
    Multithreaded image viewer window supporting instant proxy loading for huge images (>2MP),
    cursor-centered wheel zooming, click-and-drag panning, Up/Down arrow zooming,
    Mouse 4/5 navigation, and right-click close.
    """

    def __init__(self, image_path, items_list=None, parent=None):
        if isinstance(items_list, QWidget):
            parent = items_list
            items_list = getattr(parent, "loaded_items", [])

        super().__init__(parent)
        self.image_path = image_path
        self.items = items_list or []
        self.main_parent = parent

        self.current_index = 0
        for i, item in enumerate(self.items):
            if item.get("file_path") == image_path:
                self.current_index = i
                break

        self.setWindowTitle("Image Viewer")
        self.resize(900, 650)
        self.setMinimumSize(400, 300)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.thread_pool = QThreadPool.globalInstance()
        self.loader_signals = ImageLoaderSignals()
        self.loader_signals.image_loaded.connect(self.on_image_loaded)

        self.full_pixmap_size = QSize(0, 0)

        self._setup_viewer_ui()
        self.setFocus()

        # Start background thread loading immediately
        self.load_image_threaded(self.image_path)

    def load_image_threaded(self, path):
        file_title = os.path.basename(path)
        self.title_label.setText(f"🔍 Loading: {file_title}...")

        # Dispatch heavy disk I/O and decoding to background thread pool
        task = ImageLoaderTask(path, self.loader_signals)
        self.thread_pool.start(task)

    def on_image_loaded(self, file_path, pixmap, full_size):
        # Ensure signals match the current active image path
        if file_path != self.image_path:
            return

        self.full_pixmap_size = full_size
        self.canvas.set_pixmap(pixmap, file_path)

        file_title = os.path.basename(file_path)
        dim_info = f" ({full_size.width()}x{full_size.height()})" if full_size.isValid() else ""
        self.title_label.setText(f"🔍 Viewing: {file_title}{dim_info} (Double-click to toggle Fullscreen)")

    def closeEvent(self, event):
        if self.main_parent and hasattr(self.main_parent, 'workspace_grid'):
            self.main_parent.workspace_grid.selected_file_paths = {self.image_path}
            self.main_parent.workspace_grid.update()
            self.main_parent.on_card_selected(self.image_path, os.path.basename(self.image_path))
            self.main_parent.show()
        event.accept()

    def keyPressEvent(self, event: QKeyEvent):
        key = event.key()
        if key == Qt.Key.Key_Escape:
            self.close()
            event.accept()
        elif key == Qt.Key.Key_Up:
            self.canvas.zoom_by_step(1.15)
            event.accept()
        elif key == Qt.Key.Key_Down:
            self.canvas.zoom_by_step(0.85)
            event.accept()
        elif key == Qt.Key.Key_Right:
            self.navigate(1)
            event.accept()
        elif key == Qt.Key.Key_Left:
            self.navigate(-1)
            event.accept()
        else:
            super().keyPressEvent(event)

    def navigate(self, direction):
        if not self.items:
            return

        self.current_index = (self.current_index + direction) % len(self.items)
        next_item = self.items[self.current_index]
        self.image_path = next_item["file_path"]

        # Trigger background load for the new image
        self.load_image_threaded(self.image_path)

        if self.main_parent and hasattr(self.main_parent, 'workspace_grid'):
            self.main_parent.workspace_grid.selected_file_paths = {self.image_path}
            self.main_parent.workspace_grid.update()
            file_title = os.path.basename(self.image_path)
            self.main_parent.on_card_selected(self.image_path, file_title)
            self.main_parent.set_status(f"Viewing: {file_title}")

    def _setup_viewer_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(8, 8, 8, 8)

        self.container = QFrame(self)
        self.container.setStyleSheet("""
            QFrame {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 10px;
            }
        """)

        container_layout = QVBoxLayout(self.container)
        container_layout.setContentsMargins(10, 10, 10, 10)
        container_layout.setSpacing(8)

        self.title_container = QWidget(self.container)
        title_layout = QHBoxLayout(self.title_container)
        title_layout.setContentsMargins(4, 0, 4, 0)

        file_title = os.path.basename(self.image_path)
        self.title_label = QLabel(f"🔍 Loading: {file_title}...")
        self.title_label.setStyleSheet("color: #cbd5e1; font-size: 12px; font-weight: bold; background: transparent;")
        title_layout.addWidget(self.title_label)

        title_layout.addStretch()

        btn_close = QPushButton("✕")
        btn_close.setFixedSize(26, 26)
        btn_close.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_close.setStyleSheet("""
            QPushButton {
                background-color: #131b2e;
                color: #94a3b8;
                border: 1px solid #1e293b;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #ef4444;
                color: #ffffff;
                border-color: #ef4444;
            }
        """)
        btn_close.clicked.connect(self.close)
        title_layout.addWidget(btn_close)

        container_layout.addWidget(self.title_container)

        self.canvas = ImageViewerCanvas(QPixmap(), self.image_path, self)
        self.canvas.key_pressed.connect(self.keyPressEvent)
        self.canvas.double_clicked.connect(self.toggle_fullscreen)
        self.canvas.navigate_requested.connect(self.navigate)
        self.canvas.close_requested.connect(self.close)
        container_layout.addWidget(self.canvas, stretch=1)

        main_layout.addWidget(self.container)

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            self.title_container.setVisible(True)
            self.container.setStyleSheet("""
                QFrame {
                    background-color: #0b0f19;
                    border: 1px solid #1e293b;
                    border-radius: 10px;
                }
            """)
        else:
            self.showFullScreen()
            self.title_container.setVisible(False)
            self.container.setStyleSheet("""
                QFrame {
                    background-color: #0b0f19;
                    border: none;
                    border-radius: 0px;
                }
            """)
        self.canvas.reset_fit()

    def mousePressEvent(self, event):
        if not self.isFullScreen() and event.position().y() < 40:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if not self.isFullScreen() and hasattr(self, '_drag_pos') and event.position().y() < 40:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()


class ImageViewerCanvas(QWidget):
    """Custom paint canvas handling high-performance rendering, zooming, panning, and lazy full-res switching."""
    double_clicked = Signal()
    key_pressed = Signal(QKeyEvent)
    navigate_requested = Signal(int)
    close_requested = Signal()

    def __init__(self, pixmap, image_path, parent=None):
        super().__init__(parent)
        self.display_pixmap = pixmap
        self.image_path = image_path
        self.full_res_pixmap = None
        self.zoom = 1.0
        self.offset = QPoint(0, 0)
        self.dragging = False
        self.drag_start = QPoint(0, 0)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.setMouseTracking(True)
        self._initial_fit_calculated = False

    def set_pixmap(self, pixmap, image_path):
        self.display_pixmap = pixmap
        self.image_path = image_path
        self.full_res_pixmap = None
        self.reset_fit()

    def reset_fit(self):
        self.zoom = 1.0
        self.offset = QPoint(0, 0)
        self._initial_fit_calculated = False
        self.update()

    def zoom_by_step(self, zoom_multiplier):
        old_zoom = self.zoom
        new_zoom = max(0.1, min(20.0, old_zoom * zoom_multiplier))
        if new_zoom == old_zoom:
            return

        self.zoom = new_zoom
        center_pos = QPoint(self.width() // 2, self.height() // 2)
        scale_ratio = self.zoom / old_zoom
        self.offset = center_pos - (center_pos - self.offset) * scale_ratio
        self.check_full_res_load()
        self.update()

    def check_full_res_load(self):
        if self.zoom > 1.2 and self.full_res_pixmap is None:
            if self.image_path and os.path.exists(self.image_path):
                self.full_res_pixmap = QPixmap(self.image_path)

    def wheelEvent(self, event: QWheelEvent):
        angle = event.angleDelta().y()
        zoom_multiplier = 1.15 if angle > 0 else 0.85

        old_zoom = self.zoom
        new_zoom = max(0.1, min(20.0, old_zoom * zoom_multiplier))
        if new_zoom == old_zoom:
            return

        self.zoom = new_zoom
        mouse_pos = event.position().toPoint()
        scale_ratio = self.zoom / old_zoom
        self.offset = mouse_pos - (mouse_pos - self.offset) * scale_ratio

        self.check_full_res_load()
        self.update()

    def keyPressEvent(self, event: QKeyEvent):
        self.key_pressed.emit(event)

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.RightButton:
            self.close_requested.emit()
            event.accept()
            return

        if event.button() == Qt.MouseButton.BackButton:
            self.navigate_requested.emit(-1)
            event.accept()
            return
        elif event.button() == Qt.MouseButton.ForwardButton:
            self.navigate_requested.emit(1)
            event.accept()
            return

        if event.button() == Qt.MouseButton.LeftButton:
            self.dragging = True
            self.drag_start = event.position().toPoint() - self.offset
            self.setCursor(Qt.CursorShape.ClosedHandCursor)

    def mouseMoveEvent(self, event: QMouseEvent):
        if self.dragging:
            self.offset = event.position().toPoint() - self.drag_start
            self.update()

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self.dragging = False
            self.setCursor(Qt.CursorShape.OpenHandCursor)

    def mouseDoubleClickEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self.double_clicked.emit()
        super().mouseDoubleClickEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        painter.fillRect(self.rect(), QColor("#05070a"))

        active_pixmap = self.full_res_pixmap if (
            self.zoom > 1.2 and not self.full_res_pixmap.isNull() if self.full_res_pixmap else False) else self.display_pixmap

        if active_pixmap.isNull():
            return

        widget_size = self.size()
        pixmap_size = active_pixmap.size()

        fit_scale = min(
            widget_size.width() / pixmap_size.width(),
            widget_size.height() / pixmap_size.height()
        )

        current_scale = fit_scale * self.zoom
        scaled_w = int(pixmap_size.width() * current_scale)
        scaled_h = int(pixmap_size.height() * current_scale)

        if not self._initial_fit_calculated and self.offset == QPoint(0, 0):
            x = (widget_size.width() - scaled_w) // 2
            y = (widget_size.height() - scaled_h) // 2
            self.offset = QPoint(x, y)
            self._initial_fit_calculated = True

        target_rect = QRect(int(self.offset.x()), int(self.offset.y()), scaled_w, scaled_h)
        painter.drawPixmap(target_rect, active_pixmap)