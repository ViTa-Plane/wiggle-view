from PySide6.QtCore import Qt, QPoint
from PySide6.QtWidgets import QWidget, QHBoxLayout, QLabel, QPushButton ,QHBoxLayout,QVBoxLayout


class WindowDragHandler:
    """Mixin class to handle window dragging (edge-resizing handled strictly via corner grip)."""

    def __init__(self):
        self._drag_pos = QPoint()

    def handle_mouse_press(self, window, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - window.frameGeometry().topLeft()
            event.accept()
            return True
        return False

    def handle_mouse_move(self, window, event):
        if event.buttons() == Qt.MouseButton.LeftButton and not window.isMaximized():
            window.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def handle_mouse_release(self, event):
        pass


class TitleBar(QWidget, WindowDragHandler):
    """Reusable draggable title bar supporting window controls."""

    def __init__(self, title_text, parent_window, show_min_max=False):
        super().__init__()
        WindowDragHandler.__init__(self)
        self.parent_window = parent_window
        self.show_min_max = show_min_max

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 0)

        h_layout = QHBoxLayout()
        h_layout.setContentsMargins(0, 0, 0, 0)
        h_layout.setSpacing(4)

        self.title_label = QLabel(title_text)
        self.title_label.setObjectName("TitleLabel")
        self.title_label.setStyleSheet("""
            color: #f8fafc;
            font-family: sans-serif;
            font-size: 15px;
            font-weight: bold;
            background-color: transparent;
        """)
        h_layout.addWidget(self.title_label)
        h_layout.addStretch()

        if self.show_min_max:
            self.min_btn = QPushButton("—")
            self.min_btn.setFixedSize(28, 28)
            self.min_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            self.min_btn.setStyleSheet("""
                QPushButton {
                    background-color: transparent;
                    color: #94a3b8;
                    border: none;
                    border-radius: 6px;
                    font-family: sans-serif;
                    font-size: 13px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #1e293b;
                    color: #ffffff;
                }
            """)
            self.min_btn.clicked.connect(self.parent_window.showMinimized)
            h_layout.addWidget(self.min_btn)

            self.max_btn = QPushButton("□")
            self.max_btn.setFixedSize(28, 28)
            self.max_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            self.max_btn.setStyleSheet("""
                QPushButton {
                    background-color: transparent;
                    color: #94a3b8;
                    border: none;
                    border-radius: 6px;
                    font-family: sans-serif;
                    font-size: 13px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #1e293b;
                    color: #ffffff;
                }
            """)
            self.max_btn.clicked.connect(self.toggle_maximize)
            h_layout.addWidget(self.max_btn)

        self.close_btn = QPushButton("X")
        self.close_btn.setFixedSize(28, 28)
        self.close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #94a3b8;
                border: none;
                border-radius: 6px;
                font-family: sans-serif;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #c42b1c;
                color: #ffffff;
            }
        """)
        self.close_btn.clicked.connect(self.parent_window.close)
        h_layout.addWidget(self.close_btn)

        layout.addLayout(h_layout)

    def toggle_maximize(self):
        if self.parent_window.isMaximized():
            self.parent_window.showNormal()
            self.max_btn.setText("□")
        else:
            self.parent_window.showMaximized()
            self.max_btn.setText("❐")

    def mousePressEvent(self, event):
        self.handle_mouse_press(self.parent_window, event)

    def mouseMoveEvent(self, event):
        self.handle_mouse_move(self.parent_window, event)

    def mouseDoubleClickEvent(self, event):
        if self.show_min_max and event.button() == Qt.MouseButton.LeftButton:
            self.toggle_maximize()