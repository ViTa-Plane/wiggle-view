import os
import json
import tempfile
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QToolBar, QFrame,
    QGraphicsDropShadowEffect, QMenuBar, QTabWidget, QTextEdit,
    QFileDialog, QScrollArea, QSizePolicy
)
from PySide6.QtCore import Qt, QSize, QRunnable, QThreadPool, Signal, QObject, QTimer, QRect, QPoint
from PySide6.QtGui import QAction, QColor, QPixmap, QIcon, QPainter, QFont, QPen, QWheelEvent, QMouseEvent

from .img_viewer import ImageViewerWindow
from .dialogs import ChildTestDialog, AboutDialog, SettingsDialog, ResizeHandleWidget
from .workers import ThumbnailLoaderTask ,ThumbnailSignalEmitter, FolderScannerSignals, FolderScannerTask
from .widgets import WindowDragHandler, TitleBar, ResponsiveGridWidget

SETTINGS_FILE = "settings.json"


class MainWindow(QMainWindow, WindowDragHandler):
    def __init__(self):
        super().__init__(parent=None)
        WindowDragHandler.__init__(self)
        self.resize(1100, 720)
        self.setMinimumSize(750, 500)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        self.CARD_IMAGE_SIZE = 170
        self.GRID_CELL_WIDTH = 200
        self.GRID_CELL_HEIGHT = 220

        self.thread_pool = QThreadPool.globalInstance()

        self.thumbnail_signals = ThumbnailSignalEmitter()
        self.thumbnail_signals.thumbnail_ready.connect(self.on_thumbnail_ready)

        self.scanner_signals = FolderScannerSignals()
        self.scanner_signals.batch_scanned.connect(self.on_batch_scanned)
        self.scanner_signals.scan_complete.connect(self.on_scan_complete)

        self.thumb_cache_dir = os.path.join(tempfile.gettempdir(), "pyqt_slate_thumbnail_cache")
        os.makedirs(self.thumb_cache_dir, exist_ok=True)

        self.loaded_items = []
        self.pending_thumbnail_files = []
        self.batch_timer = QTimer(self)
        self.batch_timer.setInterval(25)
        self.batch_timer.timeout.connect(self.process_next_thumbnail_batch)

        self._setup_ui()
        self.load_last_folder()

    def _setup_ui(self):
        central_widget = QWidget(self)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(12, 12, 12, 12)

        self.container = QFrame(central_widget)
        self.container.setStyleSheet("""
            QFrame {
                background-color: #0d1321;
                border: 1px solid #1e293b;
                border-radius: 12px;
            }
        """)

        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 160))
        shadow.setOffset(0, 4)
        self.container.setGraphicsEffect(shadow)

        container_layout = QVBoxLayout(self.container)
        container_layout.setContentsMargins(16, 16, 16, 16)
        container_layout.setSpacing(14)

        container_layout.addWidget(TitleBar("🚀 Main Application Dashboard", self, show_min_max=True))

        self.setStyleSheet("""
            QScrollBar:vertical {
                background: #0b0f19;
                width: 12px;
                margin: 0px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background: #1e293b;
                min-height: 30px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical:hover {
                background: #334155;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
                background: none;
            }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: none;
            }

            QScrollBar:horizontal {
                background: #0b0f19;
                height: 12px;
                margin: 0px;
                border-radius: 6px;
            }
            QScrollBar::handle:horizontal {
                background: #1e293b;
                min-width: 30px;
                border-radius: 6px;
            }
            QScrollBar::handle:horizontal:hover {
                background: #334155;
            }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                width: 0px;
                background: none;
            }
            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
                background: none;
            }
        """)

        self.menu_bar = QMenuBar(self)
        self.menu_bar.setStyleSheet("""
            QMenuBar {
                background-color: #131b2e;
                color: #cbd5e1;
                font-family: sans-serif;
                font-size: 13px;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 4px;
            }
            QMenuBar::item {
                background: transparent;
                padding: 6px 12px;
                border-radius: 4px;
            }
            QMenuBar::item:selected {
                background-color: #1e293b;
                color: #ffffff;
            }
            QMenu {
                background-color: #0d1321;
                color: #cbd5e1;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 4px;
            }
            QMenu::item {
                padding: 6px 24px;
                border-radius: 4px;
            }
            QMenu::item:selected {
                background-color: #1e293b;
                color: #ffffff;
            }
        """)

        file_menu = self.menu_bar.addMenu("File")
        new_action = QAction("New", self)
        new_action.triggered.connect(lambda: self.set_status("Created new file"))

        open_last_action = QAction("Open Last Folder", self)
        open_last_action.triggered.connect(self.load_last_folder)

        open_action = QAction("Open...", self)
        open_action.triggered.connect(self.open_folder_dialog)

        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)

        file_menu.addAction(open_last_action)
        file_menu.addAction(open_action)
        file_menu.addSeparator()
        file_menu.addAction(new_action)
        file_menu.addSeparator()
        file_menu.addAction(exit_action)

        edit_menu = self.menu_bar.addMenu("Edit")
        undo_action = QAction("Undo", self)
        undo_action.triggered.connect(lambda: self.set_status("Action undone"))
        redo_action = QAction("Redo", self)
        redo_action.triggered.connect(lambda: self.set_status("Action redone"))
        edit_menu.addAction(undo_action)
        edit_menu.addAction(redo_action)

        about_menu = self.menu_bar.addMenu("About")
        about_action = QAction("About App", self)
        about_action.triggered.connect(self.show_about_dialog)
        about_menu.addAction(about_action)

        container_layout.addWidget(self.menu_bar)

        body_split_layout = QHBoxLayout()
        body_split_layout.setSpacing(12)

        self.sidebar_frame = QFrame(self)
        self.sidebar_frame.setFixedWidth(150)
        self.sidebar_frame.setStyleSheet("""
            QFrame {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 8px;
            }
        """)
        sidebar_layout = QVBoxLayout(self.sidebar_frame)
        sidebar_layout.setContentsMargins(8, 12, 8, 12)
        sidebar_layout.setSpacing(8)

        sidebar_title = QLabel("TOOLS")
        sidebar_title.setStyleSheet(
            "color: #64748b; font-family: sans-serif; font-size: 11px; font-weight: bold; background: transparent; padding-left: 4px;")
        sidebar_layout.addWidget(sidebar_title)

        tool_btn_style = """
            QPushButton {
                background-color: #131b2e;
                color: #cbd5e1;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 8px 12px;
                font-weight: 600;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #1e293b;
                color: #f8fafc;
                border-color: #334155;
            }
            QPushButton:pressed {
                background-color: #0d1321;
            }
        """

        btn_dashboard = QPushButton("📊 Dashboard")
        btn_dashboard.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_dashboard.setStyleSheet(tool_btn_style)
        btn_dashboard.clicked.connect(lambda: self.set_status("Switched to Dashboard"))
        sidebar_layout.addWidget(btn_dashboard)

        btn_analytics = QPushButton("📈 Analytics")
        btn_analytics.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_analytics.setStyleSheet(tool_btn_style)
        btn_analytics.clicked.connect(lambda: self.set_status("Switched to Analytics"))
        sidebar_layout.addWidget(btn_analytics)

        btn_settings = QPushButton("⚙️ Settings")
        btn_settings.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_settings.setStyleSheet(tool_btn_style)
        btn_settings.clicked.connect(self.open_settings_dialog)
        sidebar_layout.addWidget(btn_settings)

        sidebar_layout.addStretch()

        btn_child = QPushButton("📂 Child Win")
        btn_child.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_child.setStyleSheet("""
            QPushButton {
                background-color: #3b82f6;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 12px;
                font-weight: bold;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #2563eb;
            }
        """)
        btn_child.clicked.connect(self.open_child_window)
        sidebar_layout.addWidget(btn_child)

        body_split_layout.addWidget(self.sidebar_frame)

        center_container = QWidget(self)
        center_container.setStyleSheet("background: transparent;")
        center_layout = QVBoxLayout(center_container)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(10)

        instruction_label = QLabel("Double-click any image card to open full-screen zoomable view.")
        instruction_label.setStyleSheet(
            "color: #f8fafc; font-family: sans-serif; font-size: 13px; background: transparent;")
        center_layout.addWidget(instruction_label)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.verticalScrollBar().setSingleStep(15)
        self.scroll_area.setStyleSheet("""
            QScrollArea {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 8px;
            }
        """)

        self.workspace_grid = ResponsiveGridWidget(
            cell_width=self.GRID_CELL_WIDTH,
            cell_height=self.GRID_CELL_HEIGHT,
            image_size=self.CARD_IMAGE_SIZE
        )
        self.workspace_grid.setStyleSheet("background-color: #0b0f19;")
        self.workspace_grid.item_selected.connect(self.on_card_selected)
        self.workspace_grid.item_double_clicked.connect(self.open_image_viewer)
        self.scroll_area.setWidget(self.workspace_grid)

        center_layout.addWidget(self.scroll_area, stretch=1)
        body_split_layout.addWidget(center_container, stretch=1)

        self.right_tab_widget = QTabWidget(self)
        self.right_tab_widget.setFixedWidth(240)
        self.right_tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #1e293b;
                background-color: #0b0f19;
                border-radius: 8px;
            }
            QTabBar::tab {
                background-color: #131b2e;
                color: #94a3b8;
                border: 1px solid #1e293b;
                padding: 6px 12px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-right: 2px;
                font-size: 12px;
                font-weight: 600;
            }
            QTabBar::tab:selected {
                background-color: #1e293b;
                color: #f8fafc;
                border-bottom-color: #1e293b;
            }
            QTabBar::tab:hover {
                background-color: #1a233a;
                color: #f1f5f9;
            }
        """)

        inspector_tab = QWidget()
        inspector_layout = QVBoxLayout(inspector_tab)
        inspector_layout.setContentsMargins(10, 10, 10, 10)
        self.inspector_label = QLabel(
            f"Inspector Properties:\n\n• Folder: None Selected\n• Images Loaded: 0\n• Selected: None")
        self.inspector_label.setWordWrap(True)
        self.inspector_label.setStyleSheet("color: #cbd5e1; font-size: 12px; background: transparent;")
        inspector_layout.addWidget(self.inspector_label)
        inspector_layout.addStretch()
        self.right_tab_widget.addTab(inspector_tab, "Inspector")

        log_tab = QWidget()
        log_layout = QVBoxLayout(log_tab)
        log_layout.setContentsMargins(10, 10, 10, 10)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setPlainText("[System] App initialized successfully.")
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #05070a;
                color: #94a3b8;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 6px;
                font-size: 11px;
            }
        """)
        log_layout.addWidget(self.log_text)
        self.right_tab_widget.addTab(log_tab, "Activity")

        body_split_layout.addWidget(self.right_tab_widget)
        container_layout.addLayout(body_split_layout)

        footer_layout = QHBoxLayout()
        footer_layout.setContentsMargins(0, 0, 0, 0)

        self.status_label = QLabel("Status: Ready")
        self.status_label.setStyleSheet(
            "color: #94a3b8; font-family: sans-serif; font-size: 12px; background: transparent;")
        footer_layout.addWidget(self.status_label)

        footer_layout.addStretch()

        self.resize_handle = ResizeHandleWidget(self)
        footer_layout.addWidget(self.resize_handle, 0, Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignRight)

        container_layout.addLayout(footer_layout)

        main_layout.addWidget(self.container)
        self.setCentralWidget(central_widget)

    def load_last_folder(self):
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r") as f:
                    data = json.load(f)
                    folder = data.get("last_folder", "")
                    if folder and os.path.isdir(folder):
                        self.load_images_from_folder(folder)
            except Exception as e:
                print(f"Error loading settings: {e}")

    def save_last_folder(self, folder_path):
        try:
            data = {"last_folder": folder_path}
            with open(SETTINGS_FILE, "w") as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"Error saving settings: {e}")

    def set_status(self, message):
        self.status_label.setText(f"Status: {message}")
        if hasattr(self, 'log_text'):
            current_text = self.log_text.toPlainText()
            self.log_text.setPlainText(f"{current_text}\n• {message}")
            self.log_text.verticalScrollBar().setValue(self.log_text.verticalScrollBar().maximum())

    def open_folder_dialog(self):
        start_dir = ""
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r") as f:
                    data = json.load(f)
                    folder = data.get("last_folder", "")
                    if folder and os.path.isdir(folder):
                        start_dir = folder
            except Exception:
                pass

        if not start_dir:
            start_dir = os.path.expanduser("~")

        folder_path = QFileDialog.getExistingDirectory(
            self,
            "Select Image Folder",
            start_dir,
            QFileDialog.Option.ShowDirsOnly
        )
        if folder_path:
            self.load_images_from_folder(folder_path)

    def load_images_from_folder(self, folder_path):
        self.batch_timer.stop()
        self.loaded_items.clear()
        self.workspace_grid.set_cards(self.loaded_items)
        self.pending_thumbnail_files.clear()
        self.set_status(f"Scanning folder (threaded): {os.path.basename(folder_path)}")

        self.save_last_folder(folder_path)
        self.inspector_label.setText(
            f"Inspector Properties:\n\n• Folder: {os.path.basename(folder_path)}\n• Scanning...")

        scanner_task = FolderScannerTask(folder_path, self.scanner_signals)
        self.thread_pool.start(scanner_task)

    def on_batch_scanned(self, batch):
        for file_path, display_name in batch:
            item_data = {
                "file_path": file_path,
                "display_name": display_name,
                "thumb_path": None
            }
            self.loaded_items.append(item_data)
            self.pending_thumbnail_files.append(file_path)

        self.workspace_grid.set_cards(self.loaded_items)

        if not self.batch_timer.isActive() and self.pending_thumbnail_files:
            self.batch_timer.start()

    def on_scan_complete(self, total_count):
        self.set_status(f"Scan complete. Found {total_count} images. Loading previews...")
        self.inspector_label.setText(
            f"Inspector Properties:\n\n• Folder Selected\n• Total Images: {total_count}\n• Selected: None")

    def process_next_thumbnail_batch(self):
        if not self.pending_thumbnail_files:
            self.batch_timer.stop()
            self.set_status("Gallery loading complete.")
            return

        batch = self.pending_thumbnail_files[:15]
        self.pending_thumbnail_files = self.pending_thumbnail_files[15:]

        for file_path in batch:
            task = ThumbnailLoaderTask(file_path, self.thumb_cache_dir, self.CARD_IMAGE_SIZE, self.thumbnail_signals)
            self.thread_pool.start(task)

    def on_thumbnail_ready(self, file_path, thumb_path):
        for item in self.loaded_items:
            if item["file_path"] == file_path:
                item["thumb_path"] = thumb_path
                break

        self.workspace_grid.update()

    def on_card_selected(self, file_path, display_name):
        self.set_status(f"Selected: {display_name}")
        self.inspector_label.setText(
            f"Inspector Properties:\n\n• Selected File: {display_name}\n• Full Path: {file_path}"
        )

    def open_image_viewer(self, file_path):
        self.set_status(f"Opening viewer for: {os.path.basename(file_path)}")
        self.hide()  # Hide main window while viewer is active
        self.viewer_window = ImageViewerWindow(file_path, self)
        self.viewer_window.show()

    def open_child_window(self):
        self.set_status("Opening Child Window...")
        dialog = ChildTestDialog(self, custom_title="✨ Child Test Dialog Window")
        dialog.exec()
        self.set_status("Ready")

    def show_about_dialog(self):
        self.set_status("Viewing About Dialog...")
        dialog = AboutDialog(self)
        dialog.exec()
        self.set_status("Ready")

    def open_settings_dialog(self):
        self.set_status("Opening Settings Window...")
        dialog = SettingsDialog(self)
        dialog.exec()
        self.set_status("Ready")

    def mousePressEvent(self, event):
        self.handle_mouse_press(self, event)

    def mouseMoveEvent(self, event):
        self.handle_mouse_move(self, event)