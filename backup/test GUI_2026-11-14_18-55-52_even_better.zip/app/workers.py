import os
import hashlib

from PySide6.QtCore import Qt, QSize, QRunnable, Signal, QObject, QRect, QPoint
from PySide6.QtGui import QColor, QPixmap, QPainter, QFont, QPen, QMouseEvent


class FolderScannerSignals(QObject):
    batch_scanned = Signal(list)
    scan_complete = Signal(int)


class FolderScannerTask(QRunnable):
    def __init__(self, folder_path, signals):
        super().__init__()
        self.folder_path = folder_path
        self.signals = signals

    def run(self):
        valid_extensions = ('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.webp')
        try:
            if not os.path.isdir(self.folder_path):
                return

            batch = []
            total_count = 0

            for f in os.listdir(self.folder_path):
                if f.lower().endswith(valid_extensions):
                    file_path = os.path.join(self.folder_path, f)
                    display_name = (f[:16] + '..') if len(f) > 18 else f
                    batch.append((file_path, display_name))
                    total_count += 1

                    if len(batch) >= 50:
                        self.signals.batch_scanned.emit(batch)
                        batch = []

            if batch:
                self.signals.batch_scanned.emit(batch)

            self.signals.scan_complete.emit(total_count)
        except Exception:
            pass


class ThumbnailSignalEmitter(QObject):
    thumbnail_ready = Signal(str, str)


class ThumbnailLoaderTask(QRunnable):
    def __init__(self, file_path, cache_dir, target_size, signals):
        super().__init__()
        self.file_path = file_path
        self.cache_dir = cache_dir
        self.target_size = target_size
        self.signals = signals

    def run(self):
        try:
            path_hash = hashlib.md5(self.file_path.encode('utf-8')).hexdigest()
            thumb_filename = f"thumb_{path_hash}_{self.target_size}.jpg"
            thumb_path = os.path.join(self.cache_dir, thumb_filename)

            if not os.path.exists(thumb_path):
                pixmap = QPixmap(self.file_path)
                if not pixmap.isNull():
                    scaled = pixmap.scaled(
                        self.target_size, self.target_size,
                        Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation
                    )

                    canvas = QPixmap(self.target_size, self.target_size)
                    canvas.fill(Qt.GlobalColor.transparent)

                    painter = QPainter(canvas)
                    x = (self.target_size - scaled.width()) // 2
                    y = (self.target_size - scaled.height()) // 2
                    painter.drawPixmap(x, y, scaled)
                    painter.end()

                    canvas.save(thumb_path, "JPG", 88)

            if os.path.exists(thumb_path):
                self.signals.thumbnail_ready.emit(self.file_path, thumb_path)
        except Exception:
            pass