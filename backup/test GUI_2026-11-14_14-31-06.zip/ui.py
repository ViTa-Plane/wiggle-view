from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QToolBar, QFrame,
    QGraphicsDropShadowEffect, QMenuBar, QTabWidget, QTextEdit
)
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QAction, QColor
from functions import WindowDragHandler, TitleBar
from dialogs import ChildTestDialog, AboutDialog, SettingsDialog, ResizeHandleWidget


class MainWindow(QMainWindow, WindowDragHandler):
    """Main borderless application window complete with menu bar, left sidebar, right tabbed panel, status bar, and hardcoded styles."""

    def __init__(self):
        super().__init__(parent=None)
        WindowDragHandler.__init__(self)
        self.resize(950, 600)
        self.setMinimumSize(650, 450)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        self._setup_ui()

    def _setup_ui(self):
        central_widget = QWidget(self)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(12, 12, 12, 12)

        self.container = QFrame(central_widget)
        self.container.setStyleSheet("""
            QFrame {
                background-color: #0d1321;
                border: 1px solid #1e293b;
                border-radius: 12px;
            }
        """)

        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 160))
        shadow.setOffset(0, 4)
        self.container.setGraphicsEffect(shadow)

        container_layout = QVBoxLayout(self.container)
        container_layout.setContentsMargins(16, 16, 16, 16)
        container_layout.setSpacing(14)

        container_layout.addWidget(TitleBar("🚀 Main Application Dashboard", self, show_min_max=True))

        # --- Menu Bar (File, Edit, About) ---
        self.menu_bar = QMenuBar(self)
        self.menu_bar.setStyleSheet("""
            QMenuBar {
                background-color: #131b2e;
                color: #cbd5e1;
                font-family: sans-serif;
                font-size: 13px;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 4px;
            }
            QMenuBar::item {
                background: transparent;
                padding: 6px 12px;
                border-radius: 4px;
            }
            QMenuBar::item:selected {
                background-color: #1e293b;
                color: #ffffff;
            }
            QMenu {
                background-color: #0d1321;
                color: #cbd5e1;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 4px;
            }
            QMenu::item {
                padding: 6px 24px;
                border-radius: 4px;
            }
            QMenu::item:selected {
                background-color: #1e293b;
                color: #ffffff;
            }
        """)

        # File Menu
        file_menu = self.menu_bar.addMenu("File")
        new_action = QAction("New", self)
        new_action.triggered.connect(lambda: self.set_status("Created new file"))
        open_action = QAction("Open...", self)
        open_action.triggered.connect(lambda: self.set_status("Opened file dialog"))
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(new_action)
        file_menu.addAction(open_action)
        file_menu.addSeparator()
        file_menu.addAction(exit_action)

        # Edit Menu
        edit_menu = self.menu_bar.addMenu("Edit")
        undo_action = QAction("Undo", self)
        undo_action.triggered.connect(lambda: self.set_status("Action undone"))
        redo_action = QAction("Redo", self)
        redo_action.triggered.connect(lambda: self.set_status("Action redone"))
        edit_menu.addAction(undo_action)
        edit_menu.addAction(redo_action)

        # About Menu
        about_menu = self.menu_bar.addMenu("About")
        about_action = QAction("About App", self)
        about_action.triggered.connect(self.show_about_dialog)
        about_menu.addAction(about_action)

        container_layout.addWidget(self.menu_bar)

        # --- Main Body 3-Column Split Layout (Left Sidebar + Center Content + Right Tabbed Panel) ---
        body_split_layout = QHBoxLayout()
        body_split_layout.setSpacing(12)

        # 1. Left-Side Toolbar Panel
        self.sidebar_frame = QFrame(self)
        self.sidebar_frame.setFixedWidth(150)
        self.sidebar_frame.setStyleSheet("""
            QFrame {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 8px;
            }
        """)
        sidebar_layout = QVBoxLayout(self.sidebar_frame)
        sidebar_layout.setContentsMargins(8, 12, 8, 12)
        sidebar_layout.setSpacing(8)

        sidebar_title = QLabel("TOOLS")
        sidebar_title.setStyleSheet(
            "color: #64748b; font-family: sans-serif; font-size: 11px; font-weight: bold; background: transparent; padding-left: 4px;")
        sidebar_layout.addWidget(sidebar_title)

        tool_btn_style = """
            QPushButton {
                background-color: #131b2e;
                color: #cbd5e1;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 8px 12px;
                font-weight: 600;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #1e293b;
                color: #f8fafc;
                border-color: #334155;
            }
            QPushButton:pressed {
                background-color: #0d1321;
            }
        """

        btn_dashboard = QPushButton("📊 Dashboard")
        btn_dashboard.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_dashboard.setStyleSheet(tool_btn_style)
        btn_dashboard.clicked.connect(lambda: self.set_status("Switched to Dashboard"))
        sidebar_layout.addWidget(btn_dashboard)

        btn_analytics = QPushButton("📈 Analytics")
        btn_analytics.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_analytics.setStyleSheet(tool_btn_style)
        btn_analytics.clicked.connect(lambda: self.set_status("Switched to Analytics"))
        sidebar_layout.addWidget(btn_analytics)

        btn_settings = QPushButton("⚙️ Settings")
        btn_settings.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_settings.setStyleSheet(tool_btn_style)
        btn_settings.clicked.connect(self.open_settings_dialog)
        sidebar_layout.addWidget(btn_settings)

        sidebar_layout.addStretch()

        btn_child = QPushButton("📂 Child Win")
        btn_child.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_child.setStyleSheet("""
            QPushButton {
                background-color: #3b82f6;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 12px;
                font-weight: bold;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #2563eb;
            }
        """)
        btn_child.clicked.connect(self.open_child_window)
        sidebar_layout.addWidget(btn_child)

        body_split_layout.addWidget(self.sidebar_frame)

        # 2. Center Content Area
        content_area = QWidget(self)
        content_area.setStyleSheet("background: transparent;")
        content_layout = QVBoxLayout(content_area)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(10)

        body_label = QLabel(
            "Welcome! This layout features a left tool sidebar, center workspace, and a right-side tabbed panel.")
        body_label.setWordWrap(True)
        body_label.setStyleSheet("color: #f8fafc; font-family: sans-serif; font-size: 13px; background: transparent;")
        content_layout.addWidget(body_label)

        # Sample Workspace Widget in Center
        workspace_box = QFrame()
        workspace_box.setStyleSheet("""
            QFrame {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 8px;
            }
        """)
        ws_layout = QVBoxLayout(workspace_box)
        ws_label = QLabel("Main Workspace Canvas")
        ws_label.setStyleSheet("color: #94a3b8; font-weight: bold; background: transparent;")
        ws_layout.addWidget(ws_label)
        content_layout.addWidget(workspace_box, stretch=1)

        body_split_layout.addWidget(content_area, stretch=1)

        # 3. Right-Side Panel with Tabs (`QTabWidget`)
        self.right_tab_widget = QTabWidget(self)
        self.right_tab_widget.setFixedWidth(240)
        self.right_tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #1e293b;
                background-color: #0b0f19;
                border-radius: 8px;
            }
            QTabBar::tab {
                background-color: #131b2e;
                color: #94a3b8;
                border: 1px solid #1e293b;
                padding: 6px 12px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-right: 2px;
                font-size: 12px;
                font-weight: 600;
            }
            QTabBar::tab:selected {
                background-color: #1e293b;
                color: #f8fafc;
                border-bottom-color: #1e293b;
            }
            QTabBar::tab:hover {
                background-color: #1a233a;
                color: #f1f5f9;
            }
        """)

        # Tab 1: Inspector Panel
        inspector_tab = QWidget()
        inspector_layout = QVBoxLayout(inspector_tab)
        inspector_layout.setContentsMargins(10, 10, 10, 10)
        inspector_label = QLabel(
            "Inspector Properties:\n\n• Object: Canvas View\n• Status: Active\n• Render Mode: Hardware\n• Layer: 0")
        inspector_label.setWordWrap(True)
        inspector_label.setStyleSheet("color: #cbd5e1; font-size: 12px; background: transparent;")
        inspector_layout.addWidget(inspector_label)
        inspector_layout.addStretch()
        self.right_tab_widget.addTab(inspector_tab, "Inspector")

        # Tab 2: Activity Log Panel
        log_tab = QWidget()
        log_layout = QVBoxLayout(log_tab)
        log_layout.setContentsMargins(10, 10, 10, 10)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setPlainText(
            "[10:42:01] App initialized.\n[10:42:15] Sidebar tool clicked.\n[10:43:00] Right panel tab loaded.")
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #05070a;
                color: #94a3b8;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 6px;
                font-size: 11px;
            }
        """)
        log_layout.addWidget(self.log_text)
        self.right_tab_widget.addTab(log_tab, "Activity")

        body_split_layout.addWidget(self.right_tab_widget)

        container_layout.addLayout(body_split_layout)

        # --- Footer Layout with Status Bar & Corner Resize Handle ---
        footer_layout = QHBoxLayout()
        footer_layout.setContentsMargins(0, 0, 0, 0)

        self.status_label = QLabel("Status: Ready")
        self.status_label.setStyleSheet(
            "color: #94a3b8; font-family: sans-serif; font-size: 12px; background: transparent;")
        footer_layout.addWidget(self.status_label)

        footer_layout.addStretch()

        self.resize_handle = ResizeHandleWidget(self)
        footer_layout.addWidget(self.resize_handle, 0, Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignRight)

        container_layout.addLayout(footer_layout)

        main_layout.addWidget(self.container)
        self.setCentralWidget(central_widget)

    def set_status(self, message):
        self.status_label.setText(f"Status: {message}")
        # Log to right-side activity tab as well
        if hasattr(self, 'log_text'):
            current_text = self.log_text.toPlainText()
            self.log_text.setPlainText(f"{current_text}\n• {message}")
            self.log_text.verticalScrollBar().setValue(self.log_text.verticalScrollBar().maximum())

    def open_child_window(self):
        self.set_status("Opening Child Window...")
        dialog = ChildTestDialog(self, custom_title="✨ Child Test Dialog Window")
        dialog.exec()
        self.set_status("Ready")

    def show_about_dialog(self):
        self.set_status("Viewing About Dialog...")
        dialog = AboutDialog(self)
        dialog.exec()
        self.set_status("Ready")

    def open_settings_dialog(self):
        self.set_status("Opening Settings Window...")
        dialog = SettingsDialog(self)
        dialog.exec()
        self.set_status("Ready")

    def mousePressEvent(self, event):
        self.handle_mouse_press(self, event)

    def mouseMoveEvent(self, event):
        self.handle_mouse_move(self, event)